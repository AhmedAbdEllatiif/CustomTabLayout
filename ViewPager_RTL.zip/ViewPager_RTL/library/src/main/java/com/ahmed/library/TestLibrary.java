package com.ahmed.library;

import android.util.Log;

public class TestLibrary {

    private static final String TAG = "TestLibrary";

    public void testFun(){
        Log.e(TAG, "testFun: Ahmed is Awesome");
    }
}
