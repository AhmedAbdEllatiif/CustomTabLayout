package com.ahmed.sampleApp.Translation;

public class Languages {
    public static final String ENGLISH = "English";
    public static final String ARABIC = "ar_";
}
