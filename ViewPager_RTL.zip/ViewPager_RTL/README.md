# ViewPager supports RTL direction

This projects supports RTL with viewpager without setLayoutDirection(); ,supports viewPager with tabs, solves the problem of scrolling in viewPager with andorid SDK 28 and above. 

![alt text](https://user-images.githubusercontent.com/40568882/67781243-dd24c880-fa6f-11e9-94d3-70e200255ae2.png)

![alt text](https://user-images.githubusercontent.com/40568882/67781319-f9c10080-fa6f-11e9-919f-079cb7173731.png)


![alt text](https://user-images.githubusercontent.com/40568882/67780680-1c9ee500-fa6f-11e9-9cab-0a7d65523a1a.png)
